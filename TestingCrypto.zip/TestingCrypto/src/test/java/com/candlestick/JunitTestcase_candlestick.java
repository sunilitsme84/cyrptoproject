package com.candlestick;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.candlestick_apiResponse.CandleStickAPI;
import com.candlestick_apiResponse.GetTrades;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JunitTestcase_candlestick { 

 static String instrumentName = "BTC_USDT";
 static String time="5m";
	 
	
  static List<String> TradeResponse;
 	@Test
	
	public void a_test_get_trade_response() {
		GetTrades gettrade = new GetTrades();
		
		TradeResponse = gettrade.getTradeResponse(instrumentName);
		System.out.println(TradeResponse);
		
//		assertEquals("This is the testcase in this class", str1);	
        
	}

  @Test
	
	public void b_comparetrade() {
	  CandleStickAPI candlestickapi = new CandleStickAPI();
		
 candlestickapi.getCandleStickResponse(TradeResponse, time);
		
//		assertEquals("This is the testcase in this class", str1);	
        
	}

}
