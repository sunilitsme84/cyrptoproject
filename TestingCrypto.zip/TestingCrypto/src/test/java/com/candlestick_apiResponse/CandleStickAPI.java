package com.candlestick_apiResponse;
import static io.restassured.RestAssured.given;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CandleStickAPI {

	public void getCandleStickResponse(List<String> price, String time)
	{

		RestAssured.baseURI = "https://api.crypto.com/v2";
		Response res = given().contentType(ContentType.JSON).queryParam("instrument_name", "BTC_USDT").queryParam("timeframe", time).when()
				.get("/public/get-candlestick").then().assertThat().statusCode(200).extract().response();

		JsonPath js = new JsonPath(res.asString());
		List li_candlestck_data = js.getList("result.data");
		List o_firsttradeprice = js.getList("result.data.o");
		List c_lasttradeprice = js.getList("result.data.c");
		List h_highestpriceof1st_2nd = js.getList("result.data.h");
		List l_lowestpriceof1st_2nd = js.getList("result.data.l");


		List<String> FirstTradePrice = new ArrayList<String>();
		List<String> LastTradePrice = new ArrayList<String>();
		List<String> HighestPriceofFirst_SecondTrade = new ArrayList<String>();
		List<String> LowestPriceofFirst_SecondTrade = new ArrayList<String>();

		for(String st : price)
		{  
			for(int i=1 ; i<li_candlestck_data.size(); i++)
			{
				if(o_firsttradeprice.get(i).toString().equalsIgnoreCase(st)) 	{
					System.out.println(FirstTradePrice.add(o_firsttradeprice.get(i).toString()));	
					System.out.println("First trade Price is Matched "+ FirstTradePrice );
				}

				if(c_lasttradeprice.get(i).toString().equalsIgnoreCase(st))
				{
					System.out.println(LastTradePrice.add(c_lasttradeprice.get(i).toString()));	
					System.out.println("LastTradePrice is Matched "+ LastTradePrice );
				}

				if(h_highestpriceof1st_2nd.get(i).toString().equalsIgnoreCase(st))
				{
					System.out.println(HighestPriceofFirst_SecondTrade.add(h_highestpriceof1st_2nd.get(i).toString()));	
					System.out.println("Highest_F&SecTradeMatch "+ HighestPriceofFirst_SecondTrade );
				}

				if(l_lowestpriceof1st_2nd.get(i).toString().equalsIgnoreCase(st))
				{
					System.out.println(LowestPriceofFirst_SecondTrade.add(l_lowestpriceof1st_2nd.get(i).toString()));	
					System.out.println("Lowest_F&SecTradeMatch "+ LowestPriceofFirst_SecondTrade );
				}
			}

			if(!FirstTradePrice.isEmpty())
			{
				System.out.println("First trade price is" + FirstTradePrice);

			}
			else
			{
				System.out.println("No Match for First trade price");

			}
			if(!LastTradePrice.isEmpty())
			{
				System.out.println("Last trade price is" + LastTradePrice);

			}
			else
			{
				System.out.println("No Match for First trade price");

			}
			if(!HighestPriceofFirst_SecondTrade.isEmpty())
			{
				System.out.println("HighestPriceofFirstandSecondTrade is" + HighestPriceofFirst_SecondTrade);

			}
			else
			{
				System.out.println("No Match for HighestPriceofFirst_SecondTrade");

			}
			if(!LowestPriceofFirst_SecondTrade.isEmpty())
			{
				System.out.println("l_lowestpriceof1st_2nd is" + LowestPriceofFirst_SecondTrade.toString());

			}
			else
			{
				System.out.println("No Match for LowestPriceofFirst_SecondTrade");

			}

		}
	}

}
