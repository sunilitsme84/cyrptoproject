package com.candlestick_apiResponse;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetTrades {

	public List getTradeResponse(String instrumentName)
	{

		RestAssured.baseURI = "https://api.crypto.com/v2";
		Response res = given().contentType(ContentType.JSON).when()
				.get("/public/get-trades").then().assertThat().statusCode(200).extract().response();

		//System.out.println(res.asString());

		JsonPath js = new JsonPath(res.asString());
		List li = js.getList("result.data.i");
		List p = js.getList("result.data.p");
		
		//List<Integer> indexNum= new ArrayList<Integer>();
		List<String> PriceDetails = new ArrayList<String>();


		for(int j=1 ; j<li.size(); j++)
		{

//			System.out.println(li.size());
			if(li.get(j).equals(instrumentName))
			{
				PriceDetails.add(p.get(j).toString());
			}

		}
		return PriceDetails;
		
	}
}
